package br.com.biblioteca.marvel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MarvelApplicationTests {

	@Test
	void contextLoads() {
	}

}
